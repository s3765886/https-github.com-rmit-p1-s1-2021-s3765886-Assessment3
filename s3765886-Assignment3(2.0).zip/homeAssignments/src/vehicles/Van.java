package vehicles;
public class Van extends AbstractVehicle
{
    
}
