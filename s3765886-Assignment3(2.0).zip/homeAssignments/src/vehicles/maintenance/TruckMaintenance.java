package vehicles.maintenance;

public class TruckMaintenance extends VehicleMaintenance{
    
}
