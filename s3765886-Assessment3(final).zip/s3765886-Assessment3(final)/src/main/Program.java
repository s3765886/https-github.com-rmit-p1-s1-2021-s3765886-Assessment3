package main;

import java.io.IOException;

public class Program {
    public static void main(String[] args)throws IOException {
        Menu menu= new Menu();
        menu.run();
    }
}
