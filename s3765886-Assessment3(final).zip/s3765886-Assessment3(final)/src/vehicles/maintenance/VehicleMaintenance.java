package vehicles.maintenance;

import vehicles.jobs.Job;

public class VehicleMaintenance {

    private int odometer;
    private int odometerWhenLastServiced;
    private int odometerServiceInterval;

    public VehicleMaintenance(int odometer, int odometerWhenLastServiced, int odometerServiceInterval) {
        this.odometer = odometer;
        this.odometerWhenLastServiced = odometerWhenLastServiced;
        this.odometerServiceInterval = odometerServiceInterval;
    }

    public int getOdometer() {
        return this.odometer;
    }

    public int getOdometerWhenLastServiced() {
        return this.odometerWhenLastServiced;
    }

    public int getOdometerServiceInterval() {
        return this.odometerServiceInterval;
    }

    public boolean canTravel(Job job)
    {
        return (job.getDistance() <= getDistanceRemainingBeforeNextService());
    }

    public int getDistanceRemainingBeforeNextService()
    {
        return this.odometerServiceInterval - (this.odometer - this.odometerWhenLastServiced);
    }

    public void travel(Job job)
    {
        if(canTravel(job))
        {
            this.odometer+=job.getDistance();
        }
        else
        {
            throw new IllegalStateException("Unable to travel the desired distance");
        }
    }

    public void service()
    {
        this.odometerWhenLastServiced=this.odometer;
    }   
}

   
