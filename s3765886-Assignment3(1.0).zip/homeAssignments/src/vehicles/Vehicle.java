package vehicles;

public interface Vehicle {
    
}
