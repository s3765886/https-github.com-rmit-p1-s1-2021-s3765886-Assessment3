package vehicles;

public class Truck extends AbstractVehicle{
    
}
