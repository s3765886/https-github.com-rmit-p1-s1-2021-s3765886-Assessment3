package vehicles.jobs;

public class Job {

}
