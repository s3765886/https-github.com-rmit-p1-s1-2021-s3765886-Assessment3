package vehicles.maintenance;

import vehicles.jobs.Job;

public class TruckMaintenance extends VehicleMaintenance{

    int jobsSinceLastService;

    public TruckMaintenance(int odometer, int odometerWhenLastServiced, int odometerServiceInterval,int jobsSinceLastService) {
        super(odometer, odometerWhenLastServiced, odometerServiceInterval);
        this.jobsSinceLastService = jobsSinceLastService;
    }

    public int getJobsSinceLastService() {
        return this.jobsSinceLastService;
    }

    public int getJobsRemainingBeforeNextService()
    {
        return 5 - this.jobsSinceLastService;
    }

    @Override
    public boolean canTravel(Job job)
    {
        return super.canTravel(job) && (getJobsRemainingBeforeNextService()>0) ;
    }

    @Override
    public void travel(Job job)
    {
        if(canTravel(job))
        {
            super.travel(job);
            this.jobsSinceLastService+=1;
        }
        else
        {
            throw new IllegalStateException("Unable to travel the desired distance");
        }
        
    }

    @Override
    public void service()
    {
        super.service();
        this.jobsSinceLastService=0;
    }

    
}

