package vehicles.jobs;

public class Job {
    int distance;

    public Job(int distance) {
        this.distance = distance;
    }

    public int getDistance() {
        return this.distance;
    }

    
}
