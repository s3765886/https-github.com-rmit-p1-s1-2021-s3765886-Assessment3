package vehicles;

import vehicles.jobs.Job;
import vehicles.maintenance.TruckMaintenance;

public class Truck extends AbstractVehicle
{

    double weightLimit;


    public Truck(String rego, int year, String make, String model,Double weightLimit, TruckMaintenance maintenance) {
        super(rego, year, make, model, maintenance);
        this.weightLimit=weightLimit;
    }


    public double getWeightLimit() {
        return this.weightLimit;
    }


    @Override
    public TruckMaintenance getMaintenance()
    {
        return (TruckMaintenance)super.getMaintenance();
    }

    @Override
    public double calculateJobCost(Job job)
    {
        return 400 + 50*this.weightLimit + 1.15*job.getDistance();
    }


    @Override
    public String toString() {
        return super.toString() + ";" +
        String.format("%.1f",getWeightLimit()) + ";" +
        getMaintenance().getJobsSinceLastService();
    }    
}
