package vehicles;
import java.io.*;

import vehicles.exceptions.IllegalRegistrationException;
import vehicles.maintenance.TruckMaintenance;
import vehicles.maintenance.VehicleMaintenance;
public class VehicleSystem {

    public static final int MAX_ARRAY_SIZE = 1_000;
    private int vehicleCount;
    Vehicle vehicles[];

    public VehicleSystem()
    {
        vehicleCount=0;
        vehicles=new Vehicle[MAX_ARRAY_SIZE];
    }

    private int getVehicleCount()
    {
        return this.vehicleCount;
    }

    private void incrementVehicleCount()
    {
        this.vehicleCount++;
    }

    public void loadVehicles(String fileName)throws IOException,FileNotFoundException,IllegalRegistrationException
    {
        FileReader fileReader =  new FileReader(fileName);
        BufferedReader br = new BufferedReader(fileReader);
        String str = br.readLine();
        while(str!=null)
        {
            String temp[]=str.split(";");
            if(temp.length==7)
            {
                VehicleMaintenance vehicleMaintenance = new VehicleMaintenance(
                    Integer.parseInt(temp[4]),
                    Integer.parseInt(temp[5]),
                    Integer.parseInt(temp[6]));
                Van van = new Van(
                    temp[0],
                    Integer.parseInt(temp[1]),
                    temp[2],
                    temp[3],
                    vehicleMaintenance);
                boolean wasVanAdded = addVehicle(van);
                if(!wasVanAdded)
                {
                    throw new IllegalStateException("Duplicate Rego encountered");
                }
            }
            if(temp.length==9)
            {
                TruckMaintenance truckMaintenance = new TruckMaintenance(
                    Integer.parseInt(temp[4]),
                    Integer.parseInt(temp[5]),
                    Integer.parseInt(temp[6]),
                    Integer.parseInt(temp[8]));

                Truck truck = new Truck(
                    temp[0],
                    Integer.parseInt(temp[1]),
                    temp[2],
                    temp[3], 
                    Double.parseDouble(temp[7]),
                    truckMaintenance);
                boolean wasTruckAdded = addVehicle(truck);
                if(!wasTruckAdded)
                {
                    throw new IllegalStateException("Duplicate Rego encountered");
                }
            }
            str=br.readLine();
        }
        br.close();
       
    }

    public void saveVehicles(String fileName)throws IOException
    {
        PrintWriter printWriter = new PrintWriter(new FileWriter(fileName));
        for(int i=0; i<getVehicleCount();i++)
        {
            printWriter.println(vehicles[i].toString());
        }
        printWriter.close();
    }

    public Vehicle getVehicle(String rego)
    {
        for(int i=0;i<getVehicleCount();i++)
        {
            if(vehicles[i].getRego().equals(rego))
            return vehicles[i];
        }
        return null;
    }

    public boolean hasVehicle(String rego)
    {
        Vehicle vehicle = getVehicle(rego);
        return vehicle!=null;
    }

    public boolean addVehicle(Vehicle vehicle)
    {
        if(hasVehicle(vehicle.getRego()))
        {
            return false;
        }
       vehicles[getVehicleCount()]=vehicle;
       incrementVehicleCount();
       return true;
    }



    
}
