package vehicles.exceptions;

public class IllegalRegistrationException extends Exception{
    public IllegalRegistrationException(String message)
    {
        super(message);
    }
    
}
