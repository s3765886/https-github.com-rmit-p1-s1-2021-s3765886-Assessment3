package vehicles;

public abstract class AbstractVehicle implements Vehicle{
    
}

