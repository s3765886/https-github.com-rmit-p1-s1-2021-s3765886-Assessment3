package vehicles;

import vehicles.exceptions.IllegalRegistrationException;
import vehicles.jobs.Job;
import vehicles.maintenance.VehicleMaintenance;

public abstract class AbstractVehicle implements Vehicle{

    private String rego;
    private int year;
    private String make;
    private String model;
    private VehicleMaintenance maintenance;


    public AbstractVehicle(String rego, int year, String make, String model, VehicleMaintenance maintenance) {
        this.rego = rego;
        this.year = year;
        this.make = make;
        this.model = model;
        this.maintenance = maintenance;
        //ned to validate rego
    }

    @Override
    public String getRego() {
        return this.rego;
    }

    @Override
    public int getYear() {
        return this.year;
    }

    @Override
    public String getMake() {
        return this.make;
    }

    @Override
    public String getModel() {
        return this.model;
    }

    @Override
    public VehicleMaintenance getMaintenance() {
        return this.maintenance;
    }
    
    public static void isValidRego(String rego) throws IllegalRegistrationException
    {
        if(rego.length()!=6)
        throw new IllegalRegistrationException("Rego is not 6 in length");
        char temp[] = rego.toCharArray();
        if(!Character.isUpperCase(temp[0]) || !Character.isUpperCase(temp[1]) || !Character.isUpperCase(temp[2]))
        throw new IllegalRegistrationException("Expected UpperCase Character in rego");
        if( !Character.isDigit(temp[3]) ||  !Character.isDigit(temp[4]) ||  !Character.isDigit(temp[5]) )
        throw new IllegalRegistrationException("Expected Digit in rego");
    }

    

    @Override
    public boolean canPerformJob(Job job) {
        return maintenance.canTravel(job);
    }

    @Override
    public double performJob(Job job) throws IllegalStateException{
        maintenance.travel(job);
        return calculateJobCost(job);
    }

    //change this
    @Override
    public String toString() {
        return  getRego() + ";" +
                getYear() + ";" +
                getMake() + ";" +
                getModel() + ";" +
                maintenance.getOdometer() + ";" +
                maintenance.getOdometerWhenLastServiced() + ";" +
                maintenance.getOdometerServiceInterval();
    }
    
}