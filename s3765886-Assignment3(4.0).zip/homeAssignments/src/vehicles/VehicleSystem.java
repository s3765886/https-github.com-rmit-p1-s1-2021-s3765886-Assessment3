package vehicles;

public class VehicleSystem {

}
