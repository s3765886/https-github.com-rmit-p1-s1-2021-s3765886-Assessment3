package vehicles.exceptions;

public class IllegalRegistrationException extends Exception{
    @Override
    public String getMessage() {
        // TODO change message
        return super.getMessage();
    }
    
}