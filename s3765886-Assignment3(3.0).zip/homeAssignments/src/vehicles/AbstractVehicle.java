package vehicles;

import vehicles.jobs.Job;
import vehicles.maintenance.VehicleMaintenance;

public abstract class AbstractVehicle implements Vehicle{

    private String rego;
    private int year;
    private String make;
    private String model;
    private VehicleMaintenance maintenance;


    public AbstractVehicle(String rego, int year, String make, String model, VehicleMaintenance maintenance) {
        this.rego = rego;
        this.year = year;
        this.make = make;
        this.model = model;
        this.maintenance = maintenance;
        //ned to validate rego
    }

    @Override
    public String getRego() {
        return this.rego;
    }

    @Override
    public int getYear() {
        return this.year;
    }

    @Override
    public String getMake() {
        return this.make;
    }

    @Override
    public String getModel() {
        return this.model;
    }

    @Override
    public VehicleMaintenance getMaintenance() {
        return this.maintenance;
    }
    
    public static void isValidRego(String rego)
    {
        //logic for validation and throw error
    }

    @Override
    public boolean canPerformJob(Job job) {
        return maintenance.canTravel(job);
    }

    @Override
    public double performJob(Job job) throws IllegalStateException{
        maintenance.travel(job);
        return calculateJobCost(job);
    }

    //change this
    @Override
    public String toString() {
        return  getRego() + ";" +
                getYear() + ";" +
                getMake() + ";" +
                getModel() + ";" +
                maintenance.getOdometer() + ";" +
                maintenance.getOdometerWhenLastServiced() + ";" +
                maintenance.getOdometerServiceInterval();
    }
    
}


